# 💼 BillMaster Pro - Billing & Institute Management System

A professional, modern billing application built with PHP, MySQL, and vanilla JavaScript.

---

## 📋 Table of Contents

1. [Requirements](#requirements)
2. [Installation](#installation)
3. [Running the Application](#running-the-application)
4. [Login Credentials](#login-credentials)
5. [Features](#features)
6. [How to Use](#how-to-use)
7. [Project Structure](#project-structure)

---

## ⚙️ Requirements

- **XAMPP** (or any PHP development environment)
  - PHP 7.4 or higher
  - MySQL 5.7 or higher
  - Apache (optional, can use PHP built-in server)
- **Web Browser** (Chrome, Firefox, Edge recommended)

---

## 🚀 Installation

### Step 1: Install XAMPP

1. Download XAMPP from: https://www.apachefriends.org/
2. Install XAMPP (default location: `C:\xampp`)
3. Start **Apache** and **MySQL** from XAMPP Control Panel

### Step 2: Copy Project Files

Copy the project folder to XAMPP's web directory:

```
C:\xampp\htdocs\billmaster\
```

### Step 3: Create Database

1. Open **phpMyAdmin**: http://localhost/phpmyadmin
2. Click "New" to create a new database
3. Enter database name: `billmaster`
4. Click "Create"

### Step 4: Import Database Schema

1. In phpMyAdmin, select the `billmaster` database
2. Click on "Import" tab
3. Choose file: `C:\xampp\htdocs\billmaster\database\schema.sql`
4. Click "Go" to import

**OR** you can run this SQL manually:

```sql
-- Create database and tables (run in phpMyAdmin SQL tab)
CREATE DATABASE IF NOT EXISTS billmaster;
USE billmaster;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    role ENUM('admin', 'staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INT,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    unit VARCHAR(20) DEFAULT 'pcs',
    barcode VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Customers table
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoices table
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT,
    user_id INT,
    subtotal DECIMAL(10,2) DEFAULT 0,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'card', 'upi', 'bank_transfer', 'credit') DEFAULT 'cash',
    payment_status ENUM('paid', 'pending', 'cancelled') DEFAULT 'paid',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Invoice Items table
CREATE TABLE invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    product_id INT,
    product_name VARCHAR(200) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Settings table
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, full_name, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@billmaster.com', 'admin');

-- Insert sample categories
INSERT INTO categories (name, description) VALUES
('Electronics', 'Electronic items and accessories'),
('Groceries', 'Food and daily essentials'),
('Stationery', 'Office and school supplies');

-- Insert sample products
INSERT INTO products (name, category_id, price, stock_quantity, unit) VALUES
('Notebook', 3, 50.00, 100, 'pcs'),
('Pen Pack', 3, 30.00, 200, 'pack'),
('USB Cable', 1, 150.00, 50, 'pcs'),
('Earphones', 1, 299.00, 30, 'pcs'),
('Rice 1kg', 2, 80.00, 75, 'kg');
```

---

## ▶️ Running the Application

### Method 1: Using PHP Built-in Server (Recommended)

Open a terminal/command prompt and run:

```bash
cd C:\xampp\htdocs\billmaster
C:\xampp\php\php.exe -S localhost:8080
```

Then open: **http://localhost:8080**

### Method 2: Using XAMPP Apache

1. Start Apache from XAMPP Control Panel
2. Open: **http://localhost/billmaster**

---

## 🔐 Login Credentials

| Username | Password   | Role          |
| -------- | ---------- | ------------- |
| `admin`  | `admin123` | Administrator |

---

## ✨ Features

### 📊 Dashboard

- Real-time sales analytics
- Today's revenue & invoice count
- Sales trend charts (7/14/30 days)
- Payment method breakdown
- Top selling products
- Low stock alerts
- Hourly sales chart
- Recent invoices

### 🧾 New Bill (POS)

- Product search & category filter
- Add products to cart with click
- Quantity adjustment (+/-)
- Customer selection
- Multiple payment methods (Cash, Card, UPI, Bank)
- Payment status (Paid/Pending)
- Print invoice option

### 📋 Invoices

- View all invoices
- Filter by status (Paid/Pending)
- View invoice details
- Print invoices

### 📦 Products

- Add/Edit/Delete products
- Category assignment
- Stock management
- Price management
- Search products

### 👥 Customers

- Add/Edit/Delete customers
- Customer details (Name, Phone, Email, Address)
- Order history view
- Search customers

### 🏷️ Categories

- Add/Edit/Delete categories
- Category descriptions
- Product count per category

### ⚙️ Settings

- Business information
- Billing settings (Currency, Tax, Invoice Prefix)
- User management (Admin only)

---

## 📖 How to Use

### Creating a New Bill

1. Login with admin/admin123
2. Click **"New Bill"** in sidebar
3. **Search/Click products** to add to cart
4. Adjust **quantity** using +/- buttons
5. (Optional) Search and select a **customer**
6. Click **"Checkout"** button
7. Select **payment method** and **status**
8. Click **"Complete Payment"**
9. Print invoice if needed

### Managing Products

1. Go to **Products** page
2. Click **"Add Product"** to create new
3. Fill in: Name, Category, Price, Stock, Unit
4. Click **Save**
5. Use Edit/Delete buttons to manage existing products

### Managing Categories

1. Go to **Categories** page
2. Click **"Add Category"**
3. Enter name and description
4. Click **Save**

### Managing Customers

1. Go to **Customers** page
2. Click **"Add Customer"**
3. Fill in customer details
4. Click **Save**

### Viewing Analytics

1. Go to **Dashboard**
2. View real-time statistics
3. Use period tabs (7/14/30 days) for trends
4. Monitor low stock alerts
5. Track payment methods distribution

---

## 📁 Project Structure

```
billmaster/
├── api/                    # Backend API endpoints
│   ├── auth.php           # Authentication
│   ├── products.php       # Products CRUD
│   ├── categories.php     # Categories CRUD
│   ├── customers.php      # Customers CRUD
│   ├── invoices.php       # Invoice operations
│   ├── analytics.php      # Dashboard analytics
│   └── settings.php       # Settings management
├── assets/
│   ├── css/
│   │   ├── style.css      # Main styles
│   │   ├── layout.css     # Layout & sidebar
│   │   └── billing.css    # POS page styles
│   └── js/
│       └── app.js         # Main JavaScript
├── config/
│   └── database.php       # Database connection
├── includes/
│   └── auth.php           # Auth helper
├── database/
│   └── schema.sql         # Database schema
├── index.php              # Entry point (redirect)
├── login.html             # Login page
├── dashboard.html         # Analytics dashboard
├── billing.html           # POS / New Bill
├── invoices.html          # Invoice list
├── products.html          # Product management
├── customers.html         # Customer management
├── categories.html        # Category management
├── settings.html          # System settings
└── README.md              # This file
```

---

## 🔧 Configuration

### Database Connection

Edit `config/database.php`:

```php
$host = 'localhost';
$dbname = 'billmaster';
$username = 'root';
$password = '';
```

---

## 💡 Tips

1. **Add products first** before creating bills
2. **Set up categories** to organize products
3. **Add customers** for tracking purchases
4. **Check dashboard** regularly for insights
5. **Monitor low stock** alerts to restock items

---

## 🆘 Troubleshooting

### "Connection error" on checkout

- Ensure MySQL is running
- Check database configuration
- Login again (session may have expired)

### "Unauthorized access"

- Login again at `/login.html`
- Clear browser cookies and retry

### Products not showing

- Ensure products have `is_active = 1`
- Check if products exist in database

---

## 📞 Support

For issues or questions, check:

1. Browser console (F12 → Console tab)
2. PHP error logs
3. Database connection settings

---

**Made with ❤️ for efficient billing management**
