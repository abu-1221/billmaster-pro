<?php
/**
 * BillMaster Pro - Main Entry Point
 * Redirects to the login page or dashboard based on session
 */

session_start();

// Check if user is logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: dashboard.html');
} else {
    header('Location: login.html');
}
exit;
?>
